# ai_router module - avoid circular imports
__all__ = []