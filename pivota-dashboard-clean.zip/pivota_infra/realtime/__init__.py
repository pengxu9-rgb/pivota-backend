# Real-time metrics and WebSocket infrastructure
